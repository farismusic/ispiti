package ba.unsa.etf.rpr;

public class NeispravnaOsnovica extends Exception {
    public NeispravnaOsnovica(String text) {
        super(text);
    }
}
