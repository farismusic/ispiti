package ba.unsa.etf.rpr.p1;


public class WrongMachineState extends Exception {}

