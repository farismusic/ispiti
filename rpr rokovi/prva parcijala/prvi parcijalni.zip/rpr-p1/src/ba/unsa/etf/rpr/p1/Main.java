package ba.unsa.etf.rpr.p1;

public class Main {

    public static void main(String[] args) {
        System.out.println("Nema maina, pokretni testove!");
    }
}
